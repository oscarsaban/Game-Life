package life;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

import life.domain.Gen;
import life.domain.LifeHistory;
import life.ui.LifeController;
import life.ui.LifeView;

/**
 * Responsabilidades:
 *
 * - Leer el fichero de configuración cuyo nombre ha sido pasado por
 *   parámetro y crear una generación con dicho patrón.
 * - Crear una triada MVC y ejecutar tick sobre el controlador cada
 *   250 segundos.
 */
public class Life {

	public static final void main(String[] args) {
		if (args.length != 1) {
			System.err.println("Error de uso: el programa Life necesita un fichero como argumento");
			return;
		}

		String filename = args[0];
		Gen pattern = Gen.readConfig(filename);

		if (pattern == null)
			return;

		// MVC
		LifeHistory m = new LifeHistory(pattern);
		LifeView v = new LifeView(m);
		LifeController c = new LifeController(m , v);

		// Main loop
		while (true) {
			c.tick();
			try {
				Thread.sleep(250);
			}
			catch (InterruptedException e) {}
		}
	}
}
