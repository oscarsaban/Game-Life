package life.domain;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Arrays;
import java.util.Scanner;

/**
 * Responsabilidades:
 * - Representar una generación del juego de la vida en un
 *   mundo cuadrado con paredes.
 * - Saber qué celdas están vivas o muertas.
 * - Establecer si una celda está viva o muerta.
 * - Crear la siguiente generación.
 */
public class Gen {
	boolean[][] genes;

	/**
	 * Crea una generación sin celdas vivas en un mundo de
	 * cuadrado size x size.
	 */
	public Gen(int size) {
		genes = new boolean[size][size];
	}

	/**
	 * Devuelve el tamano del mundo de esta generación.
	 */
	public int size() {
		return genes.length;
	}

	/**
	 * Establece si la celda en la posición (x,y) está viva
	 * o muerta. Los parámetros x e y deberán ser mayores o
	 * iguales que 0 y menores que this.size().
	 */
	public void set(int x, int y, boolean live) {
		if(existeCelda(x,y)) 
			genes[x][y] = live;
	}

	private boolean existeCelda(int x, int y) {
		return x >= 0 && x < size() && y >= 0 && y < size();
	}

	/**
	 * Dice si la celda en la posición (x,y) está viva.
	 */
	public boolean live(int x, int y) {
		return existeCelda(x,y) && genes[x][y];
	}

	/**
	 * Devuelve una nueva generación aplicando las reglas del
	 * juego de la vida.
	 */
	public Gen next() {
		Gen newGen = new Gen(size());
		for(int i=0; i<size(); i++) {
			for(int j=0; j<size(); j++) {
				if(genes[i][j] && (numVivas(i,j) > 3 || numVivas(i,j) < 2)) 
					newGen.genes[i][j] = false;
				else if(!genes[i][j] && numVivas(i,j) == 3)
					newGen.genes[i][j] = true;
				else if(genes[i][j] && (numVivas(i,j) == 3 || numVivas(i,j) == 2))
					newGen.genes[i][j] = true;
				else
					newGen.genes[i][j] = false;
					
			}
		}
		return newGen;

	}

	private int numVivas(int x, int y) {
		int numVivas = 0;

		if(existeCelda(x-1,y+1) && genes[x-1][y+1])
			numVivas ++;
		if(existeCelda(x-1,y) && genes[x-1][y])
			numVivas ++;
		if(existeCelda(x-1,y-1) && genes[x-1][y-1])
			numVivas ++;
		if(existeCelda(x,y+1) && genes[x][y+1])
			numVivas ++;
		if(existeCelda(x,y-1) && genes[x][y-1])
			numVivas ++;
		if(existeCelda(x+1,y-1) && genes[x+1][y-1])
			numVivas ++;
		if(existeCelda(x+1,y) && genes[x+1][y])
			numVivas ++;
		if(existeCelda(x+1,y+1) && genes[x+1][y+1])
			numVivas ++;

		return numVivas;
	}

	/**
	 * Decide si dos generaciones son iguales.
	 */
	public boolean equals(Object o) {
		if (this == o)
			return true;
		
		if (o == null)
			return false;
		
		if(o instanceof Gen) {
			Gen g = (Gen) o;
			for(int i=0; i<size(); i++) {
				for(int j=0; j<size(); j++) {
					if(g.genes[i][j] != genes[i][j])
						return false;
				}
			}
			
			return true;
		}
		
		else
			return false;
	}
	
	/**
	 * Función que dado un nombre de fichero lo abre y lee
	 * una generación de acuerdo a los requisitos.
	 */
	public static final Gen readConfig(String filename) {
		Gen genes = null;
		
		try {
			FileReader fr = new FileReader(filename);
			Scanner sc = new Scanner(fr);

			int size = 0;
			if(sc.hasNext())
				try {
					size = Integer.parseInt(sc.next());
				} catch(NumberFormatException e) {
					System.err.println(e.getMessage());
				}

			genes = new Gen(size);

			String[] cuadricula;
			int row, col;

			while(sc.hasNext()) {
				cuadricula = sc.nextLine().split(" ");
				if(cuadricula.length == 2) {
					row = Integer.parseInt(cuadricula[0]);
					col = Integer.parseInt(cuadricula[1]);
					if(row >= 0 && row < size && col >= 0 && col < size)
						genes.set(row, col, true);
				}
			}

			sc.close();	
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		return genes;
	}
}
